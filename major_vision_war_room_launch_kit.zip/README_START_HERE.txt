MAJOR VISION PARLAYS — NBA WAR ROOM (INTERACTIVE PROTOTYPE)
==========================================================
Built October 19, 2026 for NBA Opening Night October 20, 2026.

FILES
- index.html: same interactive War Room as the standalone .html download.
  It includes 12 FICTIONAL example-stat rows so you can try the heatmap.
- preview_heatmap_mobile.png: mobile visual preview.

WHAT WORKS
- Official NBA opening-night matchups and tipoff times (3 games)
- Game filters, NBA schedule links and searchable player-prop heatmap
- Editable research rows, 10-game heat tiles and hit-rate calculations
- Parlay calculator for user-entered prices, probabilities and stake
- Actual betting results ledger with ROI and profit
- Local browser saving, JSON export/import, and copy-to-Discord summary

IMPORTANT
- The colored starter heatmap is fictional sample data. Do not post the demo
  metrics as player research or place bets based on them.
- After changing a sample row, it becomes manually entered and is still NOT
  verified unless you independently validate source, date, player and market.
- Historical L5/L10 rates do not mean future hit probability. Correlation
  changes multi-leg outcomes.
- The application is NOT connected to live NBA stats, injuries, betting odds,
  Discord or a central member database.

HOW TO OPEN ON AN IPHONE
1) Save the HTML file to Files.
2) Use a browser or HTML viewer that allows opening local HTML files.
   For easy sharing, hosting the file on an HTTPS website is recommended.

HOW TO HOST USING GITHUB PAGES (MANUAL)
1) Create a GitHub repository (e.g., major-vision-nba-warroom).
2) Add the included index.html file to the repository's root directory.
3) Go to Settings > Pages; choose Deploy from a branch, main, /(root).
4) Once GitHub supplies a public website URL, test it on mobile.
5) Post the public HTTPS website URL in your Discord channel.

NOTE ON MEMBER DATA
This is a static/offline prototype. Each device has independent local data;
edits made by you do not propagate to other visitors. You can copy your
manually entered research summary into Discord, but a live centralized War Room
requires a backend, user authentication and authorized data feeds.

SCHEDULE SOURCE
https://www.nba.com/news/2026-27-nba-regular-season-schedule
October 20, 2026: BOS at DET 3:00 PM ET; PHI at NYK 7:00 PM ET;
OKC at SAS 9:30 PM ET.

NO GUARANTEED PICKS • RESPONSIBLE BETTING
